Two-pitch arm (shoulder + elbow) with a worm-locked Fin Ray pen gripper (m3_arm): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
