Single-servo extend-and-grip (intermittent gear + barrel cam) (c3_extend_grip): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
