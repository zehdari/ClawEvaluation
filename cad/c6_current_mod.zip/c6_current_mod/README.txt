Current claw, slimmed (same rack and pinion and Dragon Skin fingers, compact head, fold-up mount) (c6_current_mod): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
