U-frame + pitch through the claw (horizontal side grabs) + parallel Fin Ray claw (2 servos) (m4_static_pitch): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
