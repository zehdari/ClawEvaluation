Rack-and-pinion Fin Ray 2.0 (repackaged drive, redesigned fingers) (c4_rack_finray2): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
