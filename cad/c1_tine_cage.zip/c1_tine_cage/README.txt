Tine-cage clamshell (single servo, gear-coupled comb hands) (c1_tine_cage): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
