Twin independent Fin Ray fingers (2 servos) (m2_twin_finger): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
