U-frame + 3:1 pitch through the claw (horizontal side grabs) + coupled wrist roll + parallel Fin Ray claw (3 servos) (m5_static_pitch_rotate): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
