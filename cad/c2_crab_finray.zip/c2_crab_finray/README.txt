Crab Fin Ray: gear-coupled pivoting Fin Ray jaws (c2_crab_finray): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
