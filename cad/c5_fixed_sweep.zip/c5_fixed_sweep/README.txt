Fixed jaw + sweeping Fin Ray jaw ("dustpan") (c5_fixed_sweep): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
