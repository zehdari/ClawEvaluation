Centric claw: 4 Fin Ray fingers, one servo (claw machine / orange peel) (c8_centric): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
