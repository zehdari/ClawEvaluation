Intermesh: ROV-style 2-vs-1 intermeshing jaws (fork + blade) on one servo (c7_intermesh): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
