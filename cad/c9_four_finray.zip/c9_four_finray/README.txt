Four Fin Ray: two opposed Fin Ray pairs on gear-coupled crab jaws (c9_four_finray): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
