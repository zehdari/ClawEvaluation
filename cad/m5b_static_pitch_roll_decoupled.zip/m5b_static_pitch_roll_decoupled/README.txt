Static mount + elbow pitch + decoupled wrist roll (G on the roll) + parallel Fin Ray claw (3 servos) (m5b_static_pitch_roll_decoupled): STEP files of every part, from the clawlab export.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Results and print orientations: see the viewer.
