# Current claw, slimmed (same rack and pinion and Dragon Skin fingers, compact head, fold-up mount) (`c6_current_mod`)

The current rack-and-pinion mechanism and TPU Gripper_V6 fingers in a compact head. The original three-face finger pocket and two real oblique bores provide retention through M4 bolts; Dragon Skin 20 faces remain mechanically keyed to the TPU. The claw uses five bar holes and a cross-connector hook, then folds upward with a ball-lock pin. Grip uses stall-and-hold and an explicit measured V6 Fin Ray approximation. Revised geometry and results require fresh evaluation.

Servos: 1. Bar holes used: k = -2, k = -1, k = +0, k = +1, k = +2. Overall check status: **WARN** (full sampling, 2026-10-18 02:27:32).

**Forgiveness score (bonus, center-only yaw-free grasping): 0.80** (0..1; grade poor; worst 2025_bottle 0.12; yaw success 82 %, capture +-20 77 %, +-40 78 %; 11 objects use center_plan()). Per object: 2025_bottle 0.12, 2024_tube_worm 0.19, 2025_bottle_lying 0.88, 2024_tube_worm_lying 0.89, 2025_ladle 0.89, 2024_nautilus 0.89, 2024_coral 0.96, 2026_bandage_box 0.97, 2026_plug_box 0.97, 2026_pill_jar 1.00, 2026_nut_and_bolt_jar 1.00.

## Design and mechanism

## Manufacturing revision

The TPU and Dragon Skin pad meshes keep their original poses. Each printed carrier retains the original 3D root
pocket, with a0.20mm rigid fit allowance and two existing oblique bores. Use two M4x50 cap screws per jaw, two OD9
washers per screw and external nylocs. Ream rigid bores4.6mm; do not drill new holes or invent nut pockets in TPU.
The40mm rigid stack leaves about3.4mm beyond the5mm nut after two0.8mm washers. Check wet fit and creep.

Print the carriers in the listed orientations with removable supports accessible through the open lower pocket.
Clear all supports and inspect the root before assembly. Carrier STL is one watertight body; there is no analytic
STEP claim. Feed TPU directly rather than through AMS. The silicone is cast into the existing hex/dovetail texture.

Use3 #8-32x1in screws at the stacked12mm mount positions and2 #8-32x3/4in screws at the outer6mm positions, with
washers and external nylocs. The mount opens in place; it requires neither drilling nor removal of robot members.

Machine the8mm-face Nitronic50HS pinion's6.1mm blind D socket with0.05mm flat clearance, clocked to the radial M3 screw and a
tooth gap, with0.4mm corner reliefs. Tap M3x0.5 from the radial2.5mm drill. M3x6 reaches the shaft flat at2.5mm
radius; its socket face lies at8.5mm, below the8.75mm tooth root. Tighten with a1.5mm AF key before installing the
servo/pinion subassembly. Inspect the supplied6mm D shaft and confirm the blank before machining. The imported
shaft mesh was inconsistent with the documented shaft; the housing remains imported, with an explicit rotating
shaft representation. Bought shaft mass is included once in the servo. The integral7.985mm lowerjournal runs in
two end-to-end8x10x10mm H370 sleeves on a machined bearing bracket; four M4x25 through bolts attach that bracket to the outer posts.
The journal shoulder has a realR0.5mm blend. The D socket ends0.25mm beyond the shaft tip; the journal shoulder stays9mm clear of the bearing. Require
UNS S20910 Nitronic50HS material certificate with0.2%yield>=690MPa for pinion, racks and bearing bracket.

The module1rack, fullbacker, V-way tongue and stop tab are one machined Nitronic50HS part per jaw. Three
integralOD10x3.75mm threaded bosses atY18.5/31.5/44.5mm,Z99.5mm (mirror forstarboard) carry positive shear into
reamed10.10±0.03mm root pockets. Deburr0.2mm tap entries; five M4x0.7 screws have>=6.3mm complete engagement; the first starboard screw has>=2.8mm complete circumference after edge allowance, plus partial threads to6.5mm. Its root-key corridor interrupts the remaining circumference. The printed tower
ends at106.5mm, below the108mm case. Inner-face M4flatheads retain the boss joint: trimM4x30to28.25±0.05mm forport
andM4x12to10.50±0.05mm forstarboard, including head. Tips recess0.45mm from the metalouterface; inspect actual
head seating andtipclearance. Use A4-70 hardware; tighten root flatheads to0.3Nm and recheck after wet conditioning.
Assemble fullyopen for head access. No externalnuts or threads enter the opposite rack travel. The original guide
profile and0.3mm running gaps are retained. Fullstall shear is carried by fitted metalbosses, not wet PETGfriction.

Grip closes until stall or the declared travel limit and holds. No crush caps are used. Six measured V6 Fin Ray
slabs model the two fingers; wing coupling, root restraint and wet pad/TPU behavior remain approximations. Fresh
full results, print support, material, structure and assembly qualifications must accompany this geometry.

## Stow

Hand stow, tool-free: pull the 3/16 in 316 SS quick-release pin (through both bracket cheeks and the drop arm, 34 mm below the hinge), swing the claw 180 deg forward and up about the 1/4 in 316 SS shoulder-screw hinge, and push the same pin through the stowed hole (34 mm above the hinge). Stowed, the claw sits upside down in front of the hull bottoms (x 0.000..0.106, everything >= 80 mm above the foot plane). Deployed datum: the QR pin in 316 drill-bushing sleeves at r = 34 mm (0.05 mm clearance = 0.085 deg = 0.35 mm at the pinch, 0.23 m from the hinge) plus a printed hard stop behind the arm (aft rotation) and an M6 ball spring plunger in a cheek that clicks into dimples in the hinge boss at 0 and 180 deg (holds the claw while the pin goes in). Transport is powered off: the QR pin alone holds the fold; the jaws slide horizontally when stowed, so gravity puts no torque on the unpowered servo and they stay where they were left (end stops: the slider tabs on the wall lugs when open, the pads on each other when closed).

Stow procedure: tool-free, ~6 s, two hands, 0 loose part(s):

1. Hold the claw by the head frame; press the button of the ball-lock pin and pull it out of the deployed hole (34 mm below the hinge). It stays on its lanyard.
2. Swing the claw 180 deg forward and up about the hinge until the spring plunger clicks into the stowed dimple (the claw now sits upside down in front of the hull bottoms).
3. Push the ball-lock pin through the stowed hole (34 mm above the hinge).
4. Deploy: the same three steps in reverse; the plunger click and the pin hole align the claw.

Powered off and stowed (servos back-drive): each servo swept over its servo range (grip 0.00..9.94 rad), 21 states: minimum clearance None mm (None): **PASS**.

Stow link vs its mount away from the hinge pin: arm / bracket 0.5 mm.

## Firmware assumptions

Continuous multi-turn position control, range0..9.94rad (1..200mm pad gap). Calibrate closed zero with a1mm feeler gauge; never home by stalling into the open backup lugs. Close until stall or the declared position limit and hold; no per-object crush cap or guessed8N/mm overtravel. Calibrate the wet TPU and servo current/lag thresholds. No holding after kill/disarm is required. Tighten the pinion on the servo before installing that subassembly into the rack box; verify gear phase and soft travel limits.

## Checks

| Check | Status | Result | Criterion |
|---|---|---|---|
| Forward reach | **PASS** | pinch x 0.1160 (+69 mm aft of today) in the water, front x 0.1667 (-69 mm vs today) | pass: pinch x <= 0.135 over the in-water poses (Concept.in_water_poses() + q_open / q_closed + transit_q; default the whole q sweep) (>= ~50 mm aft of today's 0.1846); warn: aft of today but short of the target; fail:... |
| Torpedo arm clearance | **PASS** | 2026 first target (bottom-right large, slot 0) at d = 0.60 m: clearance 22 mm; worst 2026 opening 22 mm; min standoff for the first target 0.599 m; 2024/2025 implied by 2026 (shorter bars, same standoff): 305 vs 457 mm bars at the same d = 0.60 m, ~152 mm more room | robot at the firing pose (slot aligned level with each opening, launcher mouth d = 0.6 m from the board), claw over its transit states vs the 2026 stand mesh: pass >= 20 mm everywhere, warn 0-20 mm, fail on contact; 2... |
| Low reach | **PASS** | jaw bottoms 108.7 mm below the feet (open 108.7, closed 108.7; today 80.6, target 105-110) | lowest jaw (contact parts) z over the q sweep vs the foot plane z = -0.336: pass >= 105 mm below, warn >= 80.6 mm (today), fail above today. Table clearance at the grasp pose is in the grasp check (table_reach). |
| DVL keep-out | **PASS** | min clearance 13.1 mm (beams 46.5, housing 13.1) | claw (all links incl. connector plug keep-outs) over every reachable deployed servo state (q_samples + a grid over the full servo ranges + in-water / transit poses, minus servo_exclusions) vs 4 beam keep-out cones (25... |
| Torpedo / dropper paths | **PASS** | min clearance 68.2 mm to the torpedo and dropper paths | claw over every reachable deployed servo state vs 13 mm radius cylinders along the torpedo (+x from x 0.064) and dropper (-z from z -0.273) paths: pass >= 5 mm, fail on intrusion |
| Front tension cable | **PASS** | deployed 36.1 mm, during stow 36.1 mm | front wire tension cable (x ~ -0.006, z ~ -0.296, y -0.19..0.26, thimbles included) vs the claw: deployed q sweep pass >= 10 mm, stow sweep pass >= 3 mm; warn if closer; fail on contact |
| Hand stow | **PASS** | stows -180 deg; sweep clearance 13.5 mm to the body; stowed 81 mm above the feet, front x 0.110 (c0 0.192; 5 mm past the body front) | v6.4 (user 2026-10-17: it mounts, sticks out no further than today's claw, not below the feet = fine): sweep the stow joint deployed -> stowed (servo at stow_q): FAIL only for what stops the claw from stowing: a movin... |
| Self-interference | **PASS** | link pairs min 0.75 mm, moving links vs body 36.1 mm, fixed links vs body 1.0 mm | deployed q sweep (minus states Concept.servo_exclusions() declares never commanded): every link pair except allowed_contacts / parent-child pairs must not touch (fail; jaw links of different groups driven by separate ... |
| Mass and buoyancy | **WARN** | 1753 g in air (+761 g vs the current claw 992 g, same model; brief 920 g), 952 g in water, 801 cm3 displaced, 1 servo(s); 661.3 g over the 1091.5 g allowed limit | same mass model for every concept: printed parts = density x (shell 1.2 mm + infill x core), servo 240 g + 50 g connector each, hardware list. Pass <= 1091.5 g: 10% above the current claw under this same model (992.3 ... |
| Structure (hole bar + mount) and install | **WARN** | water static 0.60 mm, 30 N landing 1.8 mm (+0.6 mm from 8 weak mount section(s) in series) (bar twist 0.13 deg), 3 g bump SF bar 27.2 / bolts 30.2 / print 28.9, first mode 14 Hz in water (17 in air); holes [-2, -1, 0, 1, 2], 2 second support(s); 8 weak section(s) < 50 % of the part's median (drop_arm, head_frame, hinge_bracket) | PROVISIONAL targets (lead): static in water <= 0.5 mm at the pinch, 30 N landing <= 3 mm, 3 g bump safety factor >= 2 on bar / bolts / print, first mode >= 15 Hz in water: warn otherwise; fail on yield or SF < 1. Inst... |
| Assembly access (screws, servo insertion, bar nuts) | **WARN** | 31 fasteners declared (0 blocked); servos: servo free assembly_sequence step 6; bar nuts 5/5 reachable; assembly sequence 6 steps (0 blocked) | FAIL only for what is physically blocked as declared: a declared fastener that neither a driver shank (6-8 mm dia by size) nor a straight hex key nor an L-key (short leg along the axis, long leg free in >= 3 of 12 dir... |
| Printability and joints (P1S) | **WARN** | 9 printed parts (2 flagged), 18 declared joints, 0 undeclared material contacts; port_slider_foot: 15 % of the surface needs support (2907 mm2) | printed parts on the Bambu Lab P1S (256 x 256 x 256 mm) in their print orientation (Part.print_up or the least-overhang best guess): fail if a part does not fit the bed (split it: split_joints), warn on > 15 % support... |
| Grasp (all objects) | **WARN** | grasp score 0.95 (min 0.86); 6 pass, 5 warn, 0 fail of 11 objects/poses (radial heading +0 deg); yaw-aligned lifts 11/11 | per object (all years + lying alternates): fail = approach lands on the object or the table structure, claw below the tabletop, jaws do not hold it (no squeeze and no cradle), grip < need (and not caged), or cradled b... |
| Approach forgiveness, center only (bonus) | **info** | bonus score 0.80 (0..1; worst 2025_bottle 0.12); yaw success 82 %, capture +-20 77 %, +-40 78 %; grade poor; 11/11 objects use center_plan() | BONUS, informational (never fails, does not affect the overall status). Headline on the competition table: the object at realistic positions (the center + 2 mid-edge positions, one per wall pair, with the footprint ~5... |
| dfc view | **info** | claw 0.05 % open / 0.01 % closed (max 0.05 % incl. holding); held objects visible: 7/11; largest (2024_coral) visible | informational (BRIEF item 6: seeing the claw / held object is not required; never fails): z-buffered dfc left image (1920 x 1200, K from robot.yaml, occluded by the robot frame / cables / feet; the hull bottom is clea... |
| Forward camera clear in the water | **PASS** | max 0.00 % of the ffc image in the water; 5 poses (declared in_water_poses() + q_open / q_closed + transit_q()) | every in-water pose (servo-driven; the hand-stowed transport pose is exempt): ffc image coverage by any claw part incl. mount, servos, plug keep-outs and cables: warn > 0.5 %, fail > 3 % or any claw pixel in the centr... |
| Servo connector / cable | **PASS** | servo pass: DVL 23 mm, paths 104 mm, stand 114 mm, slack 114 mm (default loop 150), faces 0 deg from aft | v6.4 (user 2026-10-17; the SubConn may face any direction): per servo, the plug keep-out (SubConn Micro plug + sleeve Ø15.5 x 45 mm + 15 mm straight cable) and the cable bent at 4 x OD = 36 mm toward its route, over e... |

## Grasp per object

| Object | Status | Heading (deg) | Contact | Opening at contact (mm) | Antipodal worst / cone (deg) | Caged | Contact vs equator (mm, side) | Grip / need per jaw (N) | Twist lever (mm) / margin | Capture +-20 / +-40 | Table reach (>= 50 mm from rails) / full table / edge | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2024_tube_worm | **WARN** | 0 | pinch | 28 / 48 | 4.0 / 16.7 | no | +74 at, +75 at | 18 / 0.4 | 1 / 67.86 | 33 % / 16 % | 100 % / - % / - % | captures only 33 % of +-20 mm offsets |
| 2024_tube_worm_lying | **PASS** | 0 | pinch | 22 / 110 | 6.5 / 16.7 | no | -2 at, -2 at | 29 / 0.4 | 1 / 1360.07 | 100 % / 72 % | 98 % / 86 % / 56 % |  |
| 2024_coral | **PASS** | 112 | pinch | 21 / 95 | 3.1 / 16.7 | no | +128 at, +128 at | 11 / 1.4 | 27 / 1.63 | 100 % / 72 % | 100 % / - % / - % |  |
| 2024_nautilus | **PASS** | 15 | pinch | 28 / 100 | 8.3 / 16.7 | no | +62 at, +63 at | 21 / 1.7 | 38 / 4.63 | 93 % / 61 % | 100 % / 97 % / 91 % |  |
| 2025_bottle | **WARN** | 135 | pinch | 65 / 127 | 25.8 / 16.7 | no | +72 above, +72 above | 14 / 1.3 | 1 / 4.05 | 67 % / 60 % | 100 % / - % / - % | not antipodal within the friction cone (25.8 deg > 16.7 deg), no force closure, and not caged; a contact is above the equator (object can squeeze out downward); object pushed 30 mm before the squeeze (tall upright: can tip); Fin Ray cells close up at the hold (front and back beams touch; self-contact not modeled); captures only 67 % of +-20 mm offsets |
| 2025_bottle_lying | **PASS** | 180 | pinch | 58 / 160 | 1.4 / 16.7 | no | -3 at, -2 at | 49 / 1.2 | 55 / 66.27 | 100 % / 84 % | 97 % / 79 % / 39 % |  |
| 2025_ladle | **WARN** | 180 | pinch | 55 / 130 | 6.0 / 16.7 | no | +1 at, +1 at | 15 / 0.5 | 35 / 9.58 | 100 % / 76 % | 100 % / 80 % / 35 % | Fin Ray cells close up at the hold (front and back beams touch; self-contact not modeled) |
| 2026_pill_jar | **WARN** | 113 | pinch | 70 / 130 | 2.5 / 16.7 | no | -7 at, -7 at | 29 / 0.6 | 4 / 299.91 | 100 % / 52 % | 100 % / 77 % / 23 % | Fin Ray cells close up at the hold (front and back beams touch; self-contact not modeled) |
| 2026_nut_and_bolt_jar | **WARN** | 45 | pinch | 70 / 130 | 1.8 / 16.7 | no | -8 at, -8 at | 29 / 0.6 | 3 / 337.44 | 100 % / 56 % | 100 % / 77 % / 23 % | Fin Ray cells close up at the hold (front and back beams touch; self-contact not modeled) |
| 2026_bandage_box | **PASS** | -117 | pinch | 84 / 160 | 2.9 / 16.7 | no | +1 at, +1 at | 44 / 0.5 | 5 / 318.89 | 100 % / 68 % | 97 % / 70 % / 9 % |  |
| 2026_plug_box | **PASS** | -45 | pinch | 115 / 160 | 2.1 / 16.7 | no | +2 at, +2 at | 23 / 0.5 | 1 / 135.44 | 100 % / 60 % | 97 % / 70 % / 9 % |  |

Heading = robot yaw relative to the table at the nominal placement (best of the equivalent headings). Capture = fraction of object offsets (x, y on a +-20 / +-40 mm grid, yaw +-20 deg for non-round objects) where the approach does not land on the object, the grasp feature (the nominal contact midpoint on the object, or the grasp-band section centroid) lies inside the jaws' swept closing region, and the jaws squeeze it without it twisting out. Table reach = fraction of tabletop positions where the robot at the grasp pose keeps >= 10 mm from rails, walls, fittings and baskets (best equivalent heading).

## Grasp score (graded)

**Grasp score 0.95** (mean over objects, min 0.86; 0 near misses, 4 major issues). Components in [0, 1] with the pass threshold at 0.8, weights outcome 0.25, capture 0.20, table_reach 0.15, grip 0.15, twist 0.15, contact 0.10.

| Object | Score | Outcome | Capture | Table reach | Grip | Twist | Contact | Graded issues (value / threshold, severity) |
|---|---|---|---|---|---|---|---|---|
| 2024_tube_worm | **0.86** | 1.00 | 0.28 | 1.00 | 1.00 | 1.00 | 1.00 | capture_20 0.333 / 0.8 (warn, major) |
| 2024_tube_worm_lying | **0.98** | 1.00 | 0.92 | 0.97 | 1.00 | 1.00 | 1.00 | - |
| 2024_coral | **0.96** | 1.00 | 0.92 | 1.00 | 1.00 | 0.82 | 1.00 | - |
| 2024_nautilus | **0.97** | 1.00 | 0.83 | 1.00 | 1.00 | 1.00 | 1.00 | - |
| 2025_bottle | **0.88** | 1.00 | 0.65 | 1.00 | 1.00 | 1.00 | 0.52 | capture_20 0.667 / 0.8 (warn, major); antipodal_deg 25.834 / 17.2 (warn, major); push_mm 30.0 / 15.0 (warn, major) |
| 2025_bottle_lying | **0.98** | 1.00 | 0.95 | 0.94 | 1.00 | 1.00 | 1.00 | - |
| 2025_ladle | **0.98** | 1.00 | 0.93 | 0.99 | 1.00 | 1.00 | 1.00 | - |
| 2026_pill_jar | **0.97** | 1.00 | 0.86 | 0.99 | 1.00 | 1.00 | 1.00 | - |
| 2026_nut_and_bolt_jar | **0.97** | 1.00 | 0.87 | 0.99 | 1.00 | 1.00 | 1.00 | - |
| 2026_bandage_box | **0.97** | 1.00 | 0.90 | 0.95 | 1.00 | 1.00 | 1.00 | - |
| 2026_plug_box | **0.97** | 1.00 | 0.88 | 0.95 | 1.00 | 1.00 | 1.00 | - |

## Twist (moment) per object

| Object | Worst axis | Lever (mm) | Need: static + dynamic, x2 (N mm) | Capacity (N mm) | Margin | Margin, weight only | Contact patches: L x W (mm), area (mm2), shape, r_eq (mm), material |
|---|---|---|---|---|---|---|---|
| 2024_tube_worm | closing | 1 | 7 = 2 x (0 + 3) | 485 | 67.86 | 1317.68 | port: 58 x 16, 104, line, 13.2, finray; starboard: 58 x 16, 100, line, 14.3, finray |
| 2024_tube_worm_lying | closing | 1 | 1 = 2 x (0 + 0) | 969 | 1360.07 | 4988.59 | port: 98 x 10, 189, line, 15.5, finray; starboard: 99 x 10, 222, line, 18.3, finray |
| 2024_coral | closing | 27 | 78 = 2 x (20 + 19) | 127 | 1.63 | 3.23 | port: 23 x 14, 143, area, 6.1, finray; starboard: 23 x 14, 163, area, 5.9, finray |
| 2024_nautilus | perpendicular | 38 | 106 = 2 x (35 + 18) | 491 | 4.63 | 7.07 | port: 84 x 10, 93, line, 18.3, finray; starboard: 82 x 7, 65, line, 15.1, finray |
| 2025_bottle | closing | 1 | 58 = 2 x (0 + 29) | 235 | 4.05 | 386.14 | port: 28 x 20, 28, area, 9.5, finray; starboard: 20 x 22, 31, area, 7.6, finray |
| 2025_bottle_lying | closing | 55 | 50 = 2 x (22 + 3) | 3343 | 66.27 | 76.64 | port: 111 x 48, 638, area, 34.4, finray; starboard: 110 x 46, 638, area, 34.1, finray |
| 2025_ladle | closing | 35 | 24 = 2 x (11 + 1) | 232 | 9.58 | 10.62 | port: 20 x 4, 50, line, 5.4, finray; starboard: 58 x 16, 68, line, 10.6, finray |
| 2026_pill_jar | closing | 4 | 3 = 2 x (1 + 0) | 893 | 299.91 | 443.18 | port: 52 x 19, 171, area, 15.6, finray; starboard: 54 x 19, 179, area, 15.0, finray |
| 2026_nut_and_bolt_jar | closing | 3 | 3 = 2 x (1 + 0) | 932 | 337.44 | 525.60 | port: 54 x 19, 186, area, 16.0, finray; starboard: 54 x 18, 175, line, 15.9, finray |
| 2026_bandage_box | closing | 5 | 4 = 2 x (2 + 1) | 1367 | 318.89 | 449.01 | port: 83 x 26, 405, line, 14.8, finray; starboard: 83 x 25, 413, line, 16.0, finray |
| 2026_plug_box | closing | 1 | 2 = 2 x (0 + 1) | 277 | 135.44 | 540.77 | port: 23 x 16, 150, area, 6.3, finray; starboard: 22 x 16, 118, area, 5.8, finray |

Twist (moment) check: need = 2 x (in-water weight x its lever about the axis + m_eff x 0.5 m/s^2 x the dynamic mass center's distance (worst-case direction) + COM inertia x 1.2 rad/s^2: the MPC planner's profile limits; drag is covered by the 2x); capacity = sum over the contact patches of mu (the touching pad material: Dragon Skin 1.0, TPU 0.35, else 0.30) x grip x mean slip lever (uniform pressure; patches = object surface within the hold gap + 1.5 mm of a silicone / TPU pad or + 0.5 mm of a hard face). Axes: the closing axis through the patch centroids, and the horizontal axis across it. Fail only if the weight alone twists it (capacity < 2 x weight torque) and the jaws do not block the rotation (+-15 deg test); warn if the full margin < 1.5. Wider, flatter pads raise r_eq and so the capacity.

## Structure (hole bar + mount)

| Load case | Pose | Pinch (mm) | Claw rotation (deg) | Bar twist (deg) | Bar stress (MPa) / SF | Bolt load (N) / SF | Print SF | Second-support reactions (N) |
|---|---|---|---|---|---|---|---|---|
| static_air_deployed | q_open | 0.90 | 0.18 | 0.07 | 2.6 / 90.8 | 37 / 40.4 | 58.3 | 0.0, 7.8 |
| static_air_stowed | stow_q | 0.30 | 0.07 | 0.02 | 2.9 / 81.7 | 17 / 90.5 | 86.7 | 0.0, 3.1 |
| bump_3g_stowed | stow_q | 0.80 | 0.20 | 0.07 | 8.8 / 27.2 | 50 / 30.2 | 28.9 | 0.0, 9.2 |
| static_water_deployed | q_open | 0.60 | 0.11 | 0.04 | 1.4 / 168.3 | 23 / 63.9 | 97.9 | 0.0, 5.0 |
| landing_30N_up | q_open | 1.80 | 0.36 | 0.13 | 6.9 / 34.8 | 78 / 19.2 | 29.7 | 19.4, 0.0 |
| push_10N_fore_aft | q_open | 1.40 | 0.27 | 0.10 | 4.6 / 52.7 | 56 / 26.7 | 60.3 | 14.6, 0.0 |
| push_10N_lateral | q_open | 1.20 | 0.24 | 0.00 | 6.9 / 34.6 | 30 / 50.6 | 61.5 | -0.0, -0.0 |

First mode: 16.6 Hz in air, 13.8 Hz in water (twist / rotation; added mass x1.46). Claw 1742 g; bolted holes [-2, -1, 0, 1, 2]; bar GJ 9.7 N m^2 over 368 mm between the gusset bolts.

| Model built up (30 N up at the pinch) | Pinch (mm) | Bar twist (deg) | Claw rotation (deg) |
|---|---|---|---|
| bar alone, claw rigid at the span center | 9.1 | 1.86 | 1.86 |
| + bracket in parallel over the bolted span | 8.3 | 1.70 | 1.70 |
| + boxing clamp | 8.3 | 1.70 | 1.70 |
| + mount compliance (members) | 9.5 | 1.70 | 1.93 |
| + joint supports (declared joint_supports()) and servo drives in the load path | 9.5 | 1.70 | 1.93 |
| + second supports (full model) | 1.8 | 0.13 | 0.36 |
| (reference: ideal rigid bracket on every bolted hole, no members / supports) | 6.6 | 1.35 | 1.35 |

Joints: stow hinge: 1/4 in 316 shoulder screw through both cheeks (double shear), iglidur sleeves (two_ended): 2401 N m/rad, backlash 0.10 deg. Pinch incl. backlash: static_air_deployed 1.30 mm, static_air_stowed 0.70 mm, bump_3g_stowed 1.20 mm, static_water_deployed 1.00 mm, landing_30N_up 2.20 mm, push_10N_fore_aft 1.80 mm, push_10N_lateral 1.60 mm; servo shaft side load: 

Part sections (mesh slices along each load-path part, holes / slots < 16 mm bridged; provisional): 4 part(s); no member declares `part`, so the stiffness uses the nominal member sections. Weak spots on the claw side of the bar (< 50 % of the part's median): hinge_bracket (bracket) 5 mm long at (84, 34, -236) mm: bending 16 %, torsion 19 %, area 40 %; hinge_bracket (bracket) 25 mm long at (55, 34, -200) mm: bending 118 %, torsion 23 %, area 82 %; hinge_bracket (bracket) 13 mm long at (24, 34, -177) mm: bending 3 %, torsion 70 %, area 56 %; head_frame (arm) 7 mm long at (121, 2, -313) mm: bending 40 %, torsion 6 %, area 73 %; head_frame (arm) 28 mm long at (122, 37, -344) mm: bending 0 %, torsion 0 %, area 8 %; head_frame (arm) 2 mm long at (114, 65, -309) mm: bending 114 %, torsion 17 %, area 105 %; drop_arm (arm) 25 mm long at (122, 34, -263) mm: bending 12 %, torsion 11 %, area 65 %; drop_arm (arm) 4 mm long at (80, 34, -209) mm: bending 70 %, torsion 37 %, area 78 %

Install: remove today's claw (its 4 bar bolts and the cradle under the cross-connector); hook saddle (jack screw backed off): hold it ~30 mm high in front of the hull fronts, move it aft so the arm passes between the hull lids and the C clears the cross-connector, then lower it: the C sits over the tube with 2 mm clearance, the tip drops into the slot behind it, the block slides down behind the bar's back leg, the plate lands on the bar over holes k = -2..+2; slide the hinge bracket aft over the hook plate until its lip hooks under the flange's front edge and its root block stops against the hook block (k = -1..+1); 3 x #8-32 x 1 in through the stacked12mm plates;2 x3/4in at outer6mm positions; washers and nylocs below; set the hook: turn the 45 deg M5 jack screw in (2.5 mm hex key from the front-top, between the hulls) until the tip strip bears on the back of the tube; + 1/4 turn, thread locker; slide the claw head's hinge boss between the cheeks from the front: 1/4 in shoulder screw through the cheeks and the boss sleeves, nylon-insert nut; QR pin in the deployed hole; route the SubConn cable from the aft-pointing connector up the drop arm, a service loop around the hinge, along the bracket and the hook arm, over the torpedo/dropper mount to the hull; plug in (tools: 9/64 in hex key, 11/32 in socket or nut driver, 5/32 in hex key + 3/8 in wrench (shoulder screw), 2.5 mm hex key (jack screw), 3 mm hex key (M4, drop arm); robot fasteners removed: False; slides over a member end: False)

Targets are PROVISIONAL (lead): static in water <= 0.5 mm at the pinch, 30 N landing <= 3 mm, 3 g bump SF >= 2, first mode >= 15 Hz in water. Model and limits: README (structure check).

## Assembly and the forward camera in the water

**Assembly** (WARN): 31 fasteners declared (0 blocked); servos: servo free assembly_sequence step 6; bar nuts 5/5 reachable; assembly sequence 6 steps (0 blocked)
- bar bolt k=-2 (#8, mounted): handle space blocked by robot body
- bar bolt k=-1 (#8, mounted): handle space blocked by bracket
- bar bolt k=0 (#8, mounted): handle space blocked by bracket
- bar bolt k=1 (#8, mounted): handle space blocked by bracket
- bar bolt k=2 (#8, mounted): handle space blocked by robot body
- lowerjournal bracket M4 y-29 z120 (M4, claw_off): driver clear
- lowerjournal bracket M4 y-29 z150 (M4, claw_off): driver clear
- lowerjournal bracket M4 y29 z120 (M4, claw_off): driver clear
- lowerjournal bracket M4 y29 z150 (M4, claw_off): driver clear
- servo side screw 1 (M3, claw_off): driver clear
- servo side screw 2 (M3, claw_off): driver clear
- servo side screw 3 (M3, claw_off): driver clear
- servo side screw 4 (M3, claw_off): driver clear
- pinion set screw (M3x6 head8.5mm radius, actual1.5mm AF key with75mm usable blade on removed servo/pinion subassembly; D key carries torque) (M3, claw_off): driver clear; 6.0 mm tapped_metal engagement (>= 4.5 mm)
- hinge shoulder screw (1/4 in, #10-24 nut) (#10, mounted): driver clear
- detent plunger (M6, jam nut) (M6, mounted): driver clear
- port root bolt 1 (M4 through existing TPU bore, external nyloc) (M4, claw_off): driver clear
- port root bolt 2 (M4 through existing TPU bore, external nyloc) (M4, claw_off): driver clear
- port metalbacker/root M4 1 (innerflathead,tappedmetalboss) (M4, claw_off): driver clear; 6.3 mm tapped_metal engagement (>= 6.0 mm)
- port metalbacker/root M4 2 (innerflathead,tappedmetalboss) (M4, claw_off): driver clear; 6.3 mm tapped_metal engagement (>= 6.0 mm)
- port metalbacker/root M4 3 (innerflathead,tappedmetalboss) (M4, claw_off): driver clear; 6.3 mm tapped_metal engagement (>= 6.0 mm)
- stbd root bolt 1 (M4 through existing TPU bore, external nyloc) (M4, claw_off): driver clear
- stbd root bolt 2 (M4 through existing TPU bore, external nyloc) (M4, claw_off): driver clear
- stbd metalbacker/root M4 1 (innerflathead,tappedmetalboss) (M4, claw_off): driver clear; 2.8 mm tapped_metal engagement (>= 6.0 mm)
- stbd metalbacker/root M4 2 (innerflathead,tappedmetalboss) (M4, claw_off): driver clear; 6.3 mm tapped_metal engagement (>= 6.0 mm)
- stbd metalbacker/root M4 3 (innerflathead,tappedmetalboss) (M4, claw_off): driver clear; 6.3 mm tapped_metal engagement (>= 6.0 mm)
- hook jack screw (M5 set screw in an insert, 45 deg front-top) (M5, mounted): driver clear; 8.0 mm insert engagement (>= 6.0 mm)
- split joint drop arm + yoke to the head frame screw 1 (M4, claw_off): driver clear
- split joint drop arm + yoke to the head frame screw 2 (M4, claw_off): driver clear
- split joint drop arm + yoke to the head frame screw 3 (M4, claw_off): driver clear
- split joint drop arm + yoke to the head frame screw 4 (M4, claw_off): driver clear
- servo: assembly_sequence step 6 (remove): clear
- bar nut k = -2: reachable (socket from below, deployed)
- bar nut k = -1: reachable (socket from below, deployed)
- bar nut k = 0: reachable (socket from below, deployed)
- bar nut k = 1: reachable (socket from below, deployed)
- bar nut k = 2: reachable (socket from below, deployed)

**Forward camera in the water** (PASS): max 0.00 % of the ffc image in the water; 5 poses (declared in_water_poses() + q_open / q_closed + transit_q())

## Printability and joints (Bambu Lab P1S)

| Part | Material | Print dims (mm) | Support area | Thinnest wall (mm) | Orientation | Status / issues |
|---|---|---|---|---|---|---|
| hook_saddle | petg | 127 x 83 x 240 | 7 % (3348 mm2) | 2.5 | up [0.0, 0.0, -1.0] (declared) | PASS  |
| hook_liner | tpu | 22 x 11 x 4 | 0 % (0 mm2) | 2.2 | up [-1.0, 0.0, 0.0] (declared) | PASS  |
| hinge_bracket | petg | 97 x 68 x 100 | 9 % (3870 mm2) | - | up [0.0, 0.0, 1.0] (declared) | PASS  |
| head_frame | petg | 84 x 62 x 82 | 4 % (1697 mm2) | 4.3 | up [0.0, 0.0, 1.0] (declared) | PASS  |
| drop_arm | petg | 82 x 72 x 68 | 9 % (2337 mm2) | - | up [0.0, 1.0, 0.0] (declared) | PASS  |
| port_finger | tpu | 86 x 50 x 101 | 4 % (1521 mm2) | 2.3 | up [1.0, 0.0, 0.0] (declared) | PASS  |
| port_slider_foot | petg | 59 x 52 x 83 | 15 % (2907 mm2) | 2.0 | up [-1.0, 0.0, 0.0] (declared) | WARN 15 % of the surface needs support (2907 mm2) |
| stbd_finger | tpu | 86 x 50 x 101 | 4 % (1497 mm2) | 1.7 | up [1.0, 0.0, 0.0] (declared) | PASS  |
| stbd_slider_foot | petg | 55 x 52 x 59 | 19 % (2902 mm2) | 2.0 | up [0.0, 0.0, 1.0] (declared) | WARN 19 % of the surface needs support (2902 mm2) |

Joints: pinion_bearing_bracket + head_frame (four M4x25 through bolts, washers and external nylocs on clear outer posts, clearance); pinion_lower_bush_bottom + pinion_bearing_bracket (press H370 sleeve into finish10H7 housing, press); pinion_lower_bush_top + pinion_bearing_bracket (press second H370 sleeve end-to-end, no axial preload, press); pinion + pinion_lower_bush_bottom (integral7.985mm journal in H370 ID8 running fit,9mm shoulder clearance, clearance); pinion + pinion_lower_bush_top (second H370 journal support, no axial preload, clearance); servo_output_shaft + pinion (6.1mm D socket on6mm Ti D-shaft,0.05mm flat clearance; D key carries torque, set screw retains axially, clearance); hinge_shoulder_screw + drop_arm (pin in 2 pressed-in iglidur flanged sleeve bushings, clearance); hinge_shoulder_screw + hinge_bracket (clamped by its nylon-insert nut (does not turn), clearance); qr_pin + hinge_bracket (removable pin in pressed-in 316 drill bushing sleeves, clearance); qr_pin + drop_arm (removable pin in a pressed-in 316 drill bushing sleeve, clearance); detent_plunger + hinge_bracket (screw: threaded 316 plunger + jam nut through the cheek, clearance); detent_plunger + drop_arm (spring ball on dimples in the boss face (contact only), clearance); hook_liner + hook_saddle (keyed TPU strip (key in a slot in the tip), slip); hook_jack_pad + hook_saddle (screw: acetal pad on an M5 set screw in a brass insert, clearance); port_rack + port_slider_foot (three integralOD10x3.75 metalbosses in reamed10.10 root pockets carry positive shear; innerface M4flatheads retain axially; five>=6.3mm complete threads, firststbd>=2.8mm complete plus partial to6.5mm; no wafer/friction-only path, clearance); port_finger + port_slider_foot (captured original three-face root pocket + two aligned M4 through bolts in existing TPU bores; external washers and nylocs, no TPU nut pockets, clearance); stbd_rack + stbd_slider_foot (three integralOD10x3.75 metalbosses in reamed10.10 root pockets carry positive shear; innerface M4flatheads retain axially; five>=6.3mm complete threads, firststbd>=2.8mm complete plus partial to6.5mm; no wafer/friction-only path, clearance); stbd_finger + stbd_slider_foot (captured original three-face root pocket + two aligned M4 through bolts in existing TPU bores; external washers and nylocs, no TPU nut pockets, clearance)

Print notes (Bambu Lab P1S): TPU: print separately (it cannot go through the P1S AMS); separate plates: rigid (PETG / PLA) (petg); TPU (separate print, not through the AMS) (tpu).

## Approach forgiveness per object (bonus: center-only, yaw-free)

| Object | Plan source | Yaw success | Capture +-20 | Capture +-40 | Score | Worst yaw (deg) | Worst-yaw reason |
|---|---|---|---|---|---|---|---|
| 2024_tube_worm | center_plan | 0 % | 24 % | 59 % | 0.19 | 0 | at [0.2272, 0.0]: lands on the object (arm, 29 mm up) |
| 2024_tube_worm_lying | center_plan | 100 % | 78 % | 76 % | 0.89 | 75 | ok |
| 2024_coral | center_plan | 100 % | 100 % | 80 % | 0.96 | 135 | ok |
| 2024_nautilus | center_plan | 100 % | 86 % | 68 % | 0.89 | 60 | ok |
| 2025_bottle | center_plan | 0 % | 0 % | 59 % | 0.12 | 0 | lands on the object (arm, 29 mm up) |
| 2025_bottle_lying | center_plan | 100 % | 77 % | 73 % | 0.88 | 60 | ok |
| 2025_ladle | center_plan | 100 % | 85 % | 68 % | 0.89 | 45 | ok |
| 2026_pill_jar | center_plan | 100 % | 100 % | 100 % | 1.00 | 0 | ok |
| 2026_nut_and_bolt_jar | center_plan | 100 % | 100 % | 100 % | 1.00 | 0 | ok |
| 2026_bandage_box | center_plan | 100 % | 100 % | 87 % | 0.97 | 15 | ok |
| 2026_plug_box | center_plan | 100 % | 100 % | 87 % | 0.97 | 15 | ok |

Perception gives only the object class and its top-down center, never its yaw; the robot keeps one heading. Yaw success = fraction of object yaws (360 deg, reduced by symmetry) whose zero-offset attempt passes the grasp criteria; capture = fraction over yaw x the +-20 / +-40 mm grid. Score = 0.5 yaw + 0.3 capture20 + 0.2 capture40. Informational: it never changes the overall status.

## Mass

| Part | Link | Material | Volume (cm3) | Model | Mass (g) | Displaced (cm3) |
|---|---|---|---|---|---|---|
| hook_saddle | bracket | petg | 311.6 | 2.0 mm walls + 35 % infill | 219.0 | 172.4 |
| hook_liner | bracket | tpu | 0.6 | 1.2 mm walls + 100 % infill | 0.8 | 0.6 |
| hook_jack_pad | bracket | acetal | 0.3 | solid | 0.4 | 0.3 |
| hinge_bracket | bracket | petg | 140.1 | 1.2 mm walls + 35 % infill | 105.4 | 83.0 |
| hinge_shoulder_screw | bracket | stainless | 2.3 | given | 20.0 | 0.0 |
| hinge_nut | bracket | stainless | 0.2 | given | 2.0 | 0.0 |
| detent_plunger | bracket | stainless | 0.6 | given | 4.0 | 0.0 |
| head_frame | arm | petg | 114.8 | 1.2 mm walls + 35 % infill | 91.0 | 71.7 |
| drop_arm | arm | petg | 138.7 | 1.2 mm walls + 35 % infill | 86.5 | 68.1 |
| qr_pin | arm | stainless | 2.0 | given | 11.0 | 0.0 |
| servo | arm | servo | 141.7 | given | 240.0 | 140.0 |
| servo: SubConn Micro pigtail / plug + cable | arm | subconn | - | per servo (BRIEF) | 50.0 | 15.0 |
| pinion_bearing_bracket | arm | stainless | 39.2 | solid | 313.3 | 39.2 |
| pinion_lower_bush_bottom | arm | hardware | 0.3 | given | 0.5 | 0.3 |
| pinion_lower_bush_top | arm | hardware | 0.3 | given | 0.5 | 0.3 |
| servo_output_shaft | pinion | stainless | 0.2 | given | 0.0 | 0.0 |
| pinion | pinion | stainless | 4.0 | solid | 32.0 | 4.0 |
| port_finger | jaw_port | tpu | 50.6 | 1.2 mm walls + 30 % infill | 56.7 | 46.8 |
| port_dragon_skin | jaw_port | silicone | 4.1 | solid | 4.5 | 4.1 |
| port_rack | jaw_port | stainless | 15.4 | solid | 123.4 | 15.4 |
| port_slider_foot | jaw_port | petg | 46.5 | 1.2 mm walls + 35 % infill | 39.7 | 31.2 |
| stbd_finger | jaw_stbd | tpu | 50.6 | 1.2 mm walls + 30 % infill | 56.7 | 46.8 |
| stbd_dragon_skin | jaw_stbd | silicone | 4.1 | solid | 4.5 | 4.1 |
| stbd_rack | jaw_stbd | stainless | 14.9 | solid | 119.5 | 14.9 |
| stbd_slider_foot | jaw_stbd | petg | 37.3 | 1.2 mm walls + 35 % infill | 31.7 | 25.0 |
| 4 x M4 screw + nut (split joint drop arm + yoke to the head frame) | hardware | stainless | - | split joint hardware | 11.2 | 1.4 |
| 3 x #8-32 x 1 in SHCS, 316 SS (three stacked12mm mount positions) | hardware | stainless | - | hardware | 9.3 | 1.2 |
| 2 x #8-32 x 3/4 in SHCS, 316 SS (two outer6mm mount positions) (92185A198) | hardware | stainless | - | hardware | 5.2 | 0.7 |
| 5 x #8-32 nylon-insert locknut, 316 SS (91831A009) | hardware | stainless | - | hardware | 5.0 | 0.6 |
| 5 x #8 flat washer, 316 SS (under the bar-bolt heads on PETG) (90107A008) | hardware | stainless | - | hardware | 2.0 | 0.2 |
| 2 x iglidur flanged sleeve bushing 1/4 in ID x 3/8 in OD (hinge boss) (6389K) | hardware | stainless | - | hardware | 1.2 | 0.1 |
| 5 x 316 SS drill-bushing sleeve 3/16 in ID x 5/16 in OD (QR pin holes) (8491A) | hardware | stainless | - | hardware | 6.0 | 0.8 |
| 4 x M3 x 50 SHCS + nylon-insert nut, 316 SS (servo side clamp) (92290A) | hardware | stainless | - | hardware | 13.6 | 1.7 |
| 4 x M4 x 50 SHCS + 2 OD9 washers + M4 nyloc, 316 SS (two existing oblique finger bores per jaw) | hardware | stainless | - | hardware | 31.6 | 4.0 |
| 4 x M4 x25 SHCS A4-70 +2washers+nyloc,316SS (bearing bracket to outer posts) | hardware | stainless | - | hardware | 21.6 | 2.7 |
| 3 x M4flathead A4-70,trimM4x30to28.25±.05mm inclhead (port threadedmetalboss/root) | hardware | stainless | - | hardware | 8.4 | 1.1 |
| 3 x M4flathead A4-70,trimM4x12to10.50±.05mm inclhead (stbd threadedmetalboss/root) | hardware | stainless | - | hardware | 3.6 | 0.5 |
| 1 x M3 x 6 DIN916/ISO4029 cup-point socket set screw, A4 (1.5mm AF key) (Accu SSU-M3-6-A4-BL) | hardware | stainless | - | hardware | 0.2 | 0.0 |
| 4 x M4 x 8 mm brass heat-set insert (drop arm to head frame) (94180A353) | hardware | brass | - | hardware | 3.2 | 0.4 |
| 1 x M5 x 8 mm brass heat-set insert (hook jack screw, 6.4 mm hole) (94180A361) | hardware | brass | - | hardware | 1.0 | 0.1 |
| 1 x M5 x 16 316 SS dog-point set screw (hook jack) (92313A) | hardware | stainless | - | hardware | 2.5 | 0.3 |
| 1 x TPU tip strips 1.7-4.7 mm (one fitted; the rest are spares) | hardware | stainless | - | hardware | 1.0 | 0.1 |
| 1 x M4 screw length beyond the split-joint default (2 x M4 x 80 + 2 x M4 x 16 316 SHCS vs 4 x 2.8 g) (91292A) | hardware | stainless | - | hardware | 9.4 | 1.2 |
| 1 x QR-pin lanyard + 4 cable ties (SubConn cable) | hardware | stainless | - | hardware | 4.0 | 0.5 |
| **Total** | | | | | **1753** | **801** |

In water: 952 g (9.34 N). Current claw under the same model: 992 g; BRIEF limit 920 g (research estimate with a 200 g servo guess).

## Strengths

- Preserves the current parallel-rack mechanism, TPU finger geometry and keyed Dragon Skin 20 faces.
- The carrier now captures the actual skewed root in the original three-face pocket with two aligned M4 through bolts.
- Five bar positions and a fitted cross-connector hook share the mount load; transport folds upward with a tool-free pin.
- The servo and pinion remove together after the drop arm is removed, providing a concrete service sequence.

## Weaknesses

- Revised geometry and compliant grip model require fresh full evaluation; historical scores do not describe this revision.
- The three-slab Fin Ray model idealizes root restraint, triangular-wing coupling, pad thickness and wet TPU; calibrate before fabrication.
- The compact root carriers are watertight STL meshes cropped from original CAD; no analytic STEP geometry is claimed.
- The starboard carrier needs removable print supports in its open root pocket; clean and ream the oblique bores before assembly.
- Printed slide wear, swelling, fastener preload and TPU root creep remain bench-validation requirements.
- Structural screening includes weak printed sections and provisional support assumptions; it is not a physical stiffness certification.

## Open questions

- Measure wet TPU stiffness, pad retention and creep, and pull-test both retained roots at the maximum configured grip load.
- Inspect supplied shaft dimensions and pinion fit; verify actual gear blank against the machining drawing before ordering.

## Manufacturing

Printed PETG (hook saddle, hinge bracket, head frame, drop arm, sliders/feet): 3 perimeters (1.2 mm) + 35 % gyroid, the hook saddle 5 perimeters (2 mm); the mass model uses the same. Print orientations per part in the parts table (grip loads along layers, removable support in the open root pocket). Pinion, racks and bearing bracket: machine from certified Electralloy Nitronic50HS UNS S20910 bar, MTR yield>=690MPa; no subsequent heat treatment, welding or brazing. Rack module1,36teeth,10mm face; pinion20teeth,8mm face, blind clocked 6.1mm D socket with corner reliefs (sink EDM or equivalent verified machining), integral ground7.985mm journal. Do not substitute annealed stock. Finish housing10H7 and verify pressed two H370SM-0810-10 bore8.013..8.071mm; journal7.985±.010mm. Rinse and inspect flooded gears after use; deburr all TPU-contact edges. Fingers: existing TPU Gripper_V6 with four 1.3-1.4 mm walls thickened to 1.7 mm (edit the team's SolidWorks part; modeled here by moving mesh faces <= 0.4 mm), printed separately (TPU not through the AMS); the Dragon Skin 20 faces are cast into the hex texture as today. Hook: a keyed TPU tip strip (picked from 1.7-4.7 mm on the robot) and one captive acetal jack pad on an M5 dog-point set screw in a brass insert (6.4 mm hole). Inserts: 4 x M4 x 8 mm (drop arm / head frame, >= 2.6 mm walls), 1 x M5 (jack). 316 washers under the #8 bar-bolt heads (re-torque after the first wet week: the joints rely on the bolt preload). Bushings: 2 x iglidur 1/4 in flanged sleeves (hinge), 5 x 316 drill-bushing sleeves (QR pin holes, >= 5 mm PETG around), pressed in. All printed parts are open (flood) or solid; no trapped air. Thread qualification: first starboard boss is interrupted by the root-key access corridor; credit only2.8mm complete M4 circumference, with partial threads beyond it. Generic1.5D engagement WARN remains. Complete-only nominal screens give6.21kN FEMALE Nitronic-thread envelope shear and3.59kN MALE A4-70-thread shear; neither certifies a proof-rated joint. Positive bosses carry shear; low0.3Nm tightening serves axial retention. A component-only rigid3-bolt-group screen examines direct Fx/3 and Mz with the full468N tooth resultant at all measured contact-patch vertices and both radial-X signs. The short starboard screw has909N examined external axial component; torque-coefficient K=.08/.15/.30 cases add938/500/250N clamp, giving1846/1409/1159N combined component loads versus3.59kN nominal male-thread screen. These are sensitivity cases, not guaranteed coefficient or whole-joint bounds; out-of-plane My couple, prying, friction, local printed-head bearing, extra preload, fatigue and creep are not certified. Ignore the trimmed boss in a direct-shear-only projected bearing screen: two intact OD10x3.75mm bosses give6.24MPa at468N; this excludes moment reactions. Actual pinion Tet10 tooth-root stress is391.3/369.9MPa at1.0/0.75mm meshes; the refined490.3MPa global peak is at an ideal rigid journal-support boundary, not a converged contact stress. Retain assembly and structure WARN and wet prototype/contact/creep/fatigue limits.

## Bill of materials

| Item | Qty | Material / part no. | Note |
|---|---|---|---|
| hook_saddle | 1 | PETG, 35 % infill | upside down (arch top on the bed): the arm's bending crosses the layers at <= 2.5 MPa (landing / bump hook reactions; SF > 8 vs 20 MPa) plate on the bar flange (k = -2..+2, under the hinge bracket), a block bearing on the bar's back leg over its full height, an arm up between the hull lids, an arch over the hull front cross-connector and a tip in the slot behind it; 2 mm clearance to the tube everywhere, closed on the robot by a 45 deg jack screw; 5 perimeters + 35 % gyroid |
| hook_liner | 1 | TPU, 100 % infill | flat (key up) TPU strip with a key into the tip, bears on the back of the tube: 2.2 mm nominal, supplied 1.7-4.7 mm in 0.5 mm steps; on the robot pick the one that slides in with light drag |
| hook_jack_pad | 1 | acetal (ordered) | captive acetal pad (8 x 5 mm, pressed onto the set screw's dog point) in a 6 mm pocket: it retracts fully, 4 mm stroke to the tube's front-top at 45 deg |
| hook_jack_screw | 1 | 316/18-8 stainless | M5 x 16 316 dog-point set screw in an 8 mm brass heat-set insert at 45 deg through the arm / arch corner (straight 2.5 mm hex driver from the front-top; an L-key cannot turn there) |
| hinge_bracket | 1 | PETG, 35 % infill | upright (plate up, cheek bending along the layers) 6 mm plate over bar holes k = -1..+1 stacked on the hook saddle (the same #8-32 bar bolts) running into an 18 mm lip in front of the flange edge, a closed cheek box (two 8 mm cheeks, top and bottom webs) carrying the 1/4 in hinge and both QR-pin holes (316 drill-bushing sleeves), the hard stop behind the drop arm; one body |
| hinge_shoulder_screw | 1 | 316/18-8 stainless | 1/4 in x 2-1/4 in 316 SS shoulder screw (#10-24) + nylon-insert nut: the 57.15 mm shoulder spans the 57.0 mm cheeks, so the nut clamps the shoulder, not the cheeks; turns in two iglidur sleeves in the arm boss; stays assembled (stowing needs no tools) |
| hinge_nut | 1 | 316/18-8 stainless | #10-24 external nyloc; remove separately before withdrawing shoulder screw |
| detent_plunger | 1 | 316/18-8 stainless | M6 316 SS ball spring plunger + jam nut through the port cheek; the ball clicks into the hinge-boss dimples at 0 and 180 deg |
| head_frame | 1 | PETG, 35 % infill | upright (walls on the bed); front-post bearing support holes are functional, no numerical strength claim rack box (6.5 mm walls with V-way grooves for the slider tongues + backup end-stop lugs) + 4 corner posts + both servo side plates (the servo is clamped by its 4 side M3 holes); replaces the Rack & Pinion Mount |
| drop_arm | 1 | PETG, 35 % infill | on its side (y up) 10 mm yoke over the servo + 40 x 40 mm drop arm + hinge boss (2 iglidur sleeves) + QR-pin sleeve; 4 x M4 to the head frame: 2 x M4 x 16 from above into heat-set inserts in the front posts, 2 x M4 x 80 from below (counterbored) through the back posts into heat-set inserts in the yoke |
| split_screw_heads | 1 | hardware | heads of the 2 back M4 x 80 SHCS, in counterbores 8 mm above the jaw feet |
| qr_pin | 1 | 316/18-8 stainless | 3/16 in 316 SS ball-lock quick-release pin, 2-1/2 in grip, button handle + lanyard to the bracket; moves with the arm between the deployed (34 mm below the hinge) and stowed holes |
| servo | 1 | SER-2000 servo | Blue Trail SER-2000 + HTD-45H (vendor STEP geometry, reused unchanged); imported output tessellation replaced by documented6mm rotating D-shaft (audit records discrepancy) |
| SubConn Micro pigtail / plug + cable | 1 | bought | per servo |
| pinion_bearing_bracket | 1 | 316/18-8 stainless | one-piece machined Nitronic50HS UNS S20910, certified yield>=690MPa; 22mm cantilever block,4mm flange; four M4x25 through bolts to clear outer posts |
| pinion_lower_bush_bottom | 1 | hardware | igus H370SM-0810-10,ID8/OD10/L10; two end-to-end underwater sleeves, no axial preload;10H7 housing, assembled bore8.013..8.071mm; ground journal7.985±.010mm, verify wet fit |
| pinion_lower_bush_top | 1 | hardware | igus H370SM-0810-10,ID8/OD10/L10; two end-to-end underwater sleeves, no axial preload;10H7 housing, assembled bore8.013..8.071mm; ground journal7.985±.010mm, verify wet fit |
| servo_output_shaft | 1 | 316/18-8 stainless | documented6mm Ti D-shaft on rotating output link; mass/displacement included in servo |
| pinion | 1 | 316/18-8 stainless | custom Nitronic50HS (UNS S20910), yield>=690MPa MTR;20Tmodule1/8mm face, integral7.985mm lowerjournal; blind clocked D socket on6mm Ti D-shaft with0.05mm radial/flat clearance and0.4mm corner reliefs; M3x6 reaches the flat and stays below tooth root |
| port_finger | 1 | TPU, 30 % infill | on its back face (+x up) current Gripper_V6 - square2 (TPU), 1.3-1.4 mm walls thickened to 1.7 mm |
| port_dragon_skin | 1 | silicone pad | Dragon Skin 20 (Shore 20A) cast into the finger's hex texture + dovetail notches, ~0.5 mm proud (mechanically keyed, as today); wet mu 1.0 on the smooth objects |
| port_rack | 1 | 316/18-8 stainless | one-piece machined Nitronic50HS MTR yield>=690MPa: module1rack,full3.2mm backer,V-way tongue and stop tab; three integralOD10threaded bosses in reamed thick root tower; inner-face M4flatheads: five>=6.3mm complete metal thread, firststbd>=2.8mm complete plus partial to6.5mm; tips recessed; no nuts in rack travel |
| port_slider_foot | 1 | PETG, 35 % infill | flat on its tongue side (x down): the grip and the table loads run along the layers captured finger root and thick drive tower; separate integral metal rack/backer/V-way bolts to tower (same cropped original three-face root pocket, 0.20 mm rigid fit allowance, two oblique M4 through bolts in the existing TPU bores; one watertight mesh/STL, not analytic STEP) |
| port_drive_bolt_1 | 1 | 316/18-8 stainless | A4-70 M4flathead,porttrim28.25mm/stbdtrim10.50mm; head innerface,tiprecessed.45mm,five>=6.3mm complete threads, firststbd>=2.8mm complete plus partial to6.5mm; mass once inhardware |
| port_drive_bolt_2 | 1 | 316/18-8 stainless | A4-70 M4flathead,porttrim28.25mm/stbdtrim10.50mm; head innerface,tiprecessed.45mm,five>=6.3mm complete threads, firststbd>=2.8mm complete plus partial to6.5mm; mass once inhardware |
| port_drive_bolt_3 | 1 | 316/18-8 stainless | A4-70 M4flathead,porttrim28.25mm/stbdtrim10.50mm; head innerface,tiprecessed.45mm,five>=6.3mm complete threads, firststbd>=2.8mm complete plus partial to6.5mm; mass once inhardware |
| port_root_bolt_1 | 1 | 316/18-8 stainless | M4 x 50 cap screw, two OD9 washers and external nyloc; mass in hardware, exact envelope checked independently |
| port_root_bolt_2 | 1 | 316/18-8 stainless | M4 x 50 cap screw, two OD9 washers and external nyloc; mass in hardware, exact envelope checked independently |
| stbd_finger | 1 | TPU, 30 % infill | on its back face (+x up) current Gripper_V6 - square2 Mirrored (TPU), 1.3-1.4 mm walls thickened to 1.7 mm |
| stbd_dragon_skin | 1 | silicone pad | Dragon Skin 20 (Shore 20A) cast into the finger's hex texture + dovetail notches, ~0.5 mm proud (mechanically keyed, as today); wet mu 1.0 on the smooth objects |
| stbd_rack | 1 | 316/18-8 stainless | one-piece machined Nitronic50HS MTR yield>=690MPa: module1rack,full3.2mm backer,V-way tongue and stop tab; three integralOD10threaded bosses in reamed thick root tower; inner-face M4flatheads: five>=6.3mm complete metal thread, firststbd>=2.8mm complete plus partial to6.5mm; tips recessed; no nuts in rack travel |
| stbd_slider_foot | 1 | PETG, 35 % infill | upright (z up); removable supports in open root pocket; ream oblique bores4.6mm after printing captured finger root and thick drive tower; separate integral metal rack/backer/V-way bolts to tower (same cropped original three-face root pocket, 0.20 mm rigid fit allowance, two oblique M4 through bolts in the existing TPU bores; one watertight mesh/STL, not analytic STEP) |
| stbd_drive_bolt_1 | 1 | 316/18-8 stainless | A4-70 M4flathead,porttrim28.25mm/stbdtrim10.50mm; head innerface,tiprecessed.45mm,five>=6.3mm complete threads, firststbd>=2.8mm complete plus partial to6.5mm; mass once inhardware |
| stbd_drive_bolt_2 | 1 | 316/18-8 stainless | A4-70 M4flathead,porttrim28.25mm/stbdtrim10.50mm; head innerface,tiprecessed.45mm,five>=6.3mm complete threads, firststbd>=2.8mm complete plus partial to6.5mm; mass once inhardware |
| stbd_drive_bolt_3 | 1 | 316/18-8 stainless | A4-70 M4flathead,porttrim28.25mm/stbdtrim10.50mm; head innerface,tiprecessed.45mm,five>=6.3mm complete threads, firststbd>=2.8mm complete plus partial to6.5mm; mass once inhardware |
| stbd_root_bolt_1 | 1 | 316/18-8 stainless | M4 x 50 cap screw, two OD9 washers and external nyloc; mass in hardware, exact envelope checked independently |
| stbd_root_bolt_2 | 1 | 316/18-8 stainless | M4 x 50 cap screw, two OD9 washers and external nyloc; mass in hardware, exact envelope checked independently |
| #8-32 x 1 in SHCS, 316 SS (three stacked12mm mount positions) | 3 | stainless |  |
| #8-32 x 3/4 in SHCS, 316 SS (two outer6mm mount positions) | 2 | 92185A198 |  |
| #8-32 nylon-insert locknut, 316 SS | 5 | 91831A009 |  |
| #8 flat washer, 316 SS (under the bar-bolt heads on PETG) | 5 | 90107A008 |  |
| iglidur flanged sleeve bushing 1/4 in ID x 3/8 in OD (hinge boss) | 2 | 6389K |  |
| 316 SS drill-bushing sleeve 3/16 in ID x 5/16 in OD (QR pin holes) | 5 | 8491A |  |
| M3 x 50 SHCS + nylon-insert nut, 316 SS (servo side clamp) | 4 | 92290A |  |
| M4 x 50 SHCS + 2 OD9 washers + M4 nyloc, 316 SS (two existing oblique finger bores per jaw) | 4 | stainless | measured40mm clevis stack;5mm external nyloc andtwo0.8mm washers, no TPU nut pockets |
| M4 x25 SHCS A4-70 +2washers+nyloc,316SS (bearing bracket to outer posts) | 4 | stainless |  |
| M4flathead A4-70,trimM4x30to28.25±.05mm inclhead (port threadedmetalboss/root) | 3 | stainless |  |
| M4flathead A4-70,trimM4x12to10.50±.05mm inclhead (stbd threadedmetalboss/root) | 3 | stainless |  |
| M3 x 6 DIN916/ISO4029 cup-point socket set screw, A4 (1.5mm AF key) | 1 | Accu SSU-M3-6-A4-BL | shaft-flat contact at2.5mm radius; head8.5mm, below8.75mm gear root |
| M4 x 8 mm brass heat-set insert (drop arm to head frame) | 4 | 94180A353 |  |
| M5 x 8 mm brass heat-set insert (hook jack screw, 6.4 mm hole) | 1 | 94180A361 |  |
| M5 x 16 316 SS dog-point set screw (hook jack) | 1 | 92313A |  |
| TPU tip strips 1.7-4.7 mm (one fitted; the rest are spares) | 1 | stainless |  |
| M4 screw length beyond the split-joint default (2 x M4 x 80 + 2 x M4 x 16 316 SHCS vs 4 x 2.8 g) | 1 | 91292A |  |
| QR-pin lanyard + 4 cable ties (SubConn cable) | 1 | stainless |  |

## Renders

![deployed_side.png](renders/deployed_side.png)
![deployed_front.png](renders/deployed_front.png)
![deployed_bottom.png](renders/deployed_bottom.png)
![deployed_iso.png](renders/deployed_iso.png)
![stowed_side.png](renders/stowed_side.png)
![stowed_front.png](renders/stowed_front.png)
![stowed_bottom.png](renders/stowed_bottom.png)
![stowed_iso.png](renders/stowed_iso.png)
![deployed_open_side.png](renders/deployed_open_side.png)
![deployed_open_front.png](renders/deployed_open_front.png)
![dfc_camera.png](renders/dfc_camera.png)
![grasp_2024_tube_worm.png](renders/grasp_2024_tube_worm.png)
![grasp_2024_tube_worm_lying.png](renders/grasp_2024_tube_worm_lying.png)
![grasp_2024_coral.png](renders/grasp_2024_coral.png)
![grasp_2024_nautilus.png](renders/grasp_2024_nautilus.png)
![grasp_2025_bottle.png](renders/grasp_2025_bottle.png)
![grasp_2025_bottle_lying.png](renders/grasp_2025_bottle_lying.png)
![grasp_2025_ladle.png](renders/grasp_2025_ladle.png)
![grasp_2026_pill_jar.png](renders/grasp_2026_pill_jar.png)
![grasp_2026_nut_and_bolt_jar.png](renders/grasp_2026_nut_and_bolt_jar.png)
![grasp_2026_bandage_box.png](renders/grasp_2026_bandage_box.png)
![grasp_2026_plug_box.png](renders/grasp_2026_plug_box.png)

## CAD files

See `cad_files.md` (full-resolution STEP/STL on the external SSD).


## Metadata refresh provenance

inherited underlying geometry run; not a fresh full run under revised metadata. Assembly alone was rechecked; original grasp, forgiveness, force-closure rows and all scenes/assets are preserved.
