# Current claw, slimmed (same rack and pinion and Dragon Skin fingers, compact head, fold-up mount) (c6_current_mod): CAD files

Full-resolution exports on the external SSD: `/home/ubuntu/claw_migration_1017/priority_mfg642_c6/c6_current_mod/ssd` (= `/media/ubuntu/Extreme SSD/claw_prototypes/concepts/c6_current_mod`).
Units: millimeters. STEP = CadQuery B-rep in the part's modeling frame; STL = tessellated part in its link frame; `stl_print/` = printed parts in their print orientation (build direction +z, resting on z = 0, Bambu Lab P1S).
Assembly (deployed, closed, robot origin frame, mm): `/home/ubuntu/claw_migration_1017/priority_mfg642_c6/c6_current_mod/ssd/assembly_deployed_closed_origin_mm.stl`.

| Part | Link | Material | Mass (g) | Print orientation | STEP | STL |
|---|---|---|---|---|---|---|
| hook_saddle | bracket | petg | 219.0 | upside down (arch top on the bed): the arm's bending crosses the layers at <= 2.5 MPa (landing / bump hook reactions; SF > 8 vs 20 MPa) | `hook_saddle.step` | `hook_saddle.stl` |
| hook_liner | bracket | tpu | 0.8 | flat (key up) | `hook_liner.step` | `hook_liner.stl` |
| hook_jack_pad | bracket | acetal | 0.4 | - | `hook_jack_pad.step` | `hook_jack_pad.stl` |
| hook_jack_screw | bracket | stainless | 2.5 | - | `hook_jack_screw.step` | `hook_jack_screw.stl` |
| hinge_bracket | bracket | petg | 105.4 | upright (plate up, cheek bending along the layers) | `hinge_bracket.step` | `hinge_bracket.stl` |
| hinge_shoulder_screw | bracket | stainless | 20.0 | - | `hinge_shoulder_screw.step` | `hinge_shoulder_screw.stl` |
| hinge_nut | bracket | stainless | 2.0 | - | `hinge_nut.step` | `hinge_nut.stl` |
| detent_plunger | bracket | stainless | 4.0 | - | `detent_plunger.step` | `detent_plunger.stl` |
| head_frame | arm | petg | 91.0 | upright (walls on the bed); front-post bearing support holes are functional, no numerical strength claim | `head_frame.step` | `head_frame.stl` |
| drop_arm | arm | petg | 86.5 | on its side (y up) | `drop_arm.step` | `drop_arm.stl` |
| split_screw_heads | arm | hardware | 2.4 | - | `split_screw_heads.step` | `split_screw_heads.stl` |
| qr_pin | arm | stainless | 11.0 | - | `qr_pin.step` | `qr_pin.stl` |
| pinion_bearing_bracket | arm | stainless | 313.3 | - | `pinion_bearing_bracket.step` | `pinion_bearing_bracket.stl` |
| pinion_lower_bush_bottom | arm | hardware | 0.5 | - | `pinion_lower_bush_bottom.step` | `pinion_lower_bush_bottom.stl` |
| pinion_lower_bush_top | arm | hardware | 0.5 | - | `pinion_lower_bush_top.step` | `pinion_lower_bush_top.stl` |
| pinion | pinion | stainless | 32.0 | - | `pinion.step` | `pinion.stl` |
| port_finger | jaw_port | tpu | 56.7 | on its back face (+x up) | - | `port_finger.stl` |
| port_dragon_skin | jaw_port | silicone | 4.5 | - | - | `port_dragon_skin.stl` |
| port_rack | jaw_port | stainless | 123.4 | - | `port_rack.step` | `port_rack.stl` |
| port_slider_foot | jaw_port | petg | 39.7 | flat on its tongue side (x down): the grip and the table loads run along the layers | - | `port_slider_foot.stl` |
| port_drive_bolt_1 | jaw_port | stainless | 3.1 | - | `port_drive_bolt_1.step` | `port_drive_bolt_1.stl` |
| port_drive_bolt_2 | jaw_port | stainless | 3.1 | - | `port_drive_bolt_2.step` | `port_drive_bolt_2.stl` |
| port_drive_bolt_3 | jaw_port | stainless | 3.1 | - | `port_drive_bolt_3.step` | `port_drive_bolt_3.stl` |
| port_root_bolt_1 | jaw_port | stainless | 8.4 | - | - | `port_root_bolt_1.stl` |
| port_root_bolt_2 | jaw_port | stainless | 8.4 | - | - | `port_root_bolt_2.stl` |
| stbd_finger | jaw_stbd | tpu | 56.7 | on its back face (+x up) | - | `stbd_finger.stl` |
| stbd_dragon_skin | jaw_stbd | silicone | 4.5 | - | - | `stbd_dragon_skin.stl` |
| stbd_rack | jaw_stbd | stainless | 119.5 | - | `stbd_rack.step` | `stbd_rack.stl` |
| stbd_slider_foot | jaw_stbd | petg | 31.7 | upright (z up); removable supports in open root pocket; ream oblique bores4.6mm after printing | - | `stbd_slider_foot.stl` |
| stbd_drive_bolt_1 | jaw_stbd | stainless | 1.3 | - | `stbd_drive_bolt_1.step` | `stbd_drive_bolt_1.stl` |
| stbd_drive_bolt_2 | jaw_stbd | stainless | 1.3 | - | `stbd_drive_bolt_2.step` | `stbd_drive_bolt_2.stl` |
| stbd_drive_bolt_3 | jaw_stbd | stainless | 1.3 | - | `stbd_drive_bolt_3.step` | `stbd_drive_bolt_3.stl` |
| stbd_root_bolt_1 | jaw_stbd | stainless | 8.4 | - | - | `stbd_root_bolt_1.stl` |
| stbd_root_bolt_2 | jaw_stbd | stainless | 8.4 | - | - | `stbd_root_bolt_2.stl` |
