Current claw, slimmed (same rack and pinion and Dragon Skin fingers, compact head, fold-up mount) (c6_current_mod): evaluated CAD and manufacturing files.
All STEP and STL dimensions are millimeters.
step/: solid CAD parts; stl/: exported part meshes; stl_print/: printed parts oriented on the build plate.
Mesh-based parts, including TPU fingers and imported roots, are supplied as STL.
docs/report.md contains materials, hardware, assembly notes, and the evaluation including remaining warnings.
docs/cad_files.md maps parts to exports. Use archive-relative paths for the included files.
Target printer: Bambu Lab P1S, build volume 256 x 256 x 256 mm. Follow each part's material and process in the report.
